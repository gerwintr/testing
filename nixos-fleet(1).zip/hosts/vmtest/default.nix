# Local test host: base + desktop role, no Entra, no disko, a local test user.
# Run with: nixos-rebuild build-vm --flake .#vmtest && ./result/bin/run-vmtest-vm
{ ... }:
{
  # Only needed so the config evaluates; build-vm replaces the disk layout.
  fileSystems."/" = { device = "/dev/disk/by-label/nixos"; fsType = "ext4"; };

  users.users.tester = {
    isNormalUser = true;
    initialPassword = "test";     # test only; never in a real host
  };

  virtualisation.vmVariant.virtualisation = {
    memorySize = 4096;
    cores = 2;
  };

  system.stateVersion = "26.05";
}
