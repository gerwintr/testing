# Base: applies to every device. Think "security baseline + update policy".
{ config, lib, pkgs, ... }:
{
  # --- Nix itself -----------------------------------------------------------
  nix.settings = {
    experimental-features = [ "nix-command" "flakes" ];
    # Private binary cache filled by CI, so devices download instead of compile.
    # TODO: enable once the cache exists; an unreachable cache slows every build.
    # extra-substituters = [ "https://nix-cache.example.internal" ];
    # extra-trusted-public-keys = [ "nix-cache.example.internal-1:REPLACE_WITH_CACHE_PUBLIC_KEY" ];
    allowed-users = [ "@wheel" ];
  };
  nix.gc = { automatic = true; dates = "weekly"; options = "--delete-older-than 14d"; };
  nix.optimise.automatic = true;

  # --- Updates: pull-based, applied on next reboot ---------------------------
  system.autoUpgrade = {
    enable = true;
    flake = "git+https://git.example.internal/werkplek/nixos-fleet?ref=stable";
    dates = "04:00";
    randomizedDelaySec = "45min";
    persistent = true;      # catch up if the laptop was off
    operation = "boot";     # no live switch under the user; activates at reboot
    allowReboot = false;
  };

  # --- Boot ------------------------------------------------------------------
  boot.loader.systemd-boot.enable = true;
  boot.loader.systemd-boot.configurationLimit = 10;   # rollback depth
  boot.loader.efi.canTouchEfiVariables = true;
  boot.initrd.systemd.enable = true;                  # needed for TPM2 LUKS unlock

  # --- Accounts --------------------------------------------------------------
  users.mutableUsers = false;          # users only exist if declared (or via IdP)
  users.users.root.hashedPassword = "!";
  # Break-glass admin; hash comes from sops-nix/agenix in a real setup.
  users.users.breakglass = {
    isNormalUser = true;
    extraGroups = [ "wheel" ];
    hashedPasswordFile = "/run/secrets/breakglass-hash";
  };
  security.sudo.execWheelOnly = true;
  security.sudo.wheelNeedsPassword = true;

  # --- Hardening -------------------------------------------------------------
  networking.firewall.enable = true;
  services.openssh.enable = lib.mkDefault false;
  security.apparmor.enable = true;
  services.fwupd.enable = true;        # firmware via LVFS
  zramSwap.enable = true;
  services.journald.extraConfig = "SystemMaxUse=500M";

  # --- Locale ----------------------------------------------------------------
  time.timeZone = "Europe/Amsterdam";
  i18n.defaultLocale = "en_US.UTF-8";
  i18n.extraLocaleSettings.LC_TIME = "nl_NL.UTF-8";
}
