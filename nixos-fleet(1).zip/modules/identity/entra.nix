# Identity: Entra ID sign-in via Himmelblau.
# Swappable layer: replace this file with identity/oidc.nix (Keycloak/Authentik) later.
{ himmelblau, ... }:
{
  imports = [ himmelblau.nixosModules.himmelblau ];

  services.himmelblau = {
    enable = true;
    settings = {
      domain = "example.com";
      pam_allow_groups = [ "ENTRA-GROUP-OBJECT-ID" ];   # pilot users only
      local_groups = [ "users" ];                        # no wheel for end users
    };
  };
}
