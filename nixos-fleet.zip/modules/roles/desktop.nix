# Role: standard end-user desktop.
{ pkgs, ... }:
{
  services.xserver.enable = true;
  services.displayManager.gdm.enable = true;
  services.desktopManager.gnome.enable = true;
  services.gnome.gnome-keyring.enable = true;   # Secret portal, needed for SSO token storage

  networking.networkmanager.enable = true;
  services.pipewire = { enable = true; pulse.enable = true; };
  services.printing.enable = true;
  hardware.bluetooth.enable = true;

  # Only allow apps we ship; users cannot install system software.
  environment.systemPackages = with pkgs; [ firefox libreoffice ];
  services.flatpak.enable = false;

  # Firefox policy = the "configuration profile" for the browser.
  programs.firefox = {
    enable = true;
    policies = {
      DisableTelemetry = true;
      DisableFirefoxAccounts = true;
      PasswordManagerEnabled = false;
      Homepage = { URL = "https://intranet.example.internal"; Locked = true; };
    };
  };
}
