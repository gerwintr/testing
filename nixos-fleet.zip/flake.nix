{
  description = "NixOS pilot fleet - base + roles";

  inputs = {
    # Pin one release branch. CI bumps flake.lock; devices never update inputs themselves.
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";

    disko = {
      url = "github:nix-community/disko";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    himmelblau = {
      url = "github:himmelblau-idm/himmelblau";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = { self, nixpkgs, disko, himmelblau, ... }:
    let
      # One function builds every device: base is always included,
      # the role and identity modules are the "assignment".
      mkHost = name: extraModules: nixpkgs.lib.nixosSystem {
        system = "x86_64-linux";
        specialArgs = { inherit himmelblau; };
        modules = [
          disko.nixosModules.disko
          ./modules/base.nix
          (./hosts + "/${name}")
          { networking.hostName = name; }
        ] ++ extraModules;
      };
    in
    {
      nixosConfigurations = {
        pilot-01 = mkHost "pilot-01" [
          ./modules/roles/desktop.nix
          ./modules/identity/entra.nix
        ];
      };
    };
}
