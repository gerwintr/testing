# Per-device: disk layout (disko) + hardware. Only thing that differs per laptop.
{ ... }:
{
  imports = [ ./hardware-configuration.nix ];   # from `nixos-generate-config`

  disko.devices.disk.main = {
    type = "disk";
    device = "/dev/nvme0n1";
    content = {
      type = "gpt";
      partitions = {
        ESP = {
          size = "1G";
          type = "EF00";
          content = { type = "filesystem"; format = "vfat"; mountpoint = "/boot"; mountOptions = [ "umask=0077" ]; };
        };
        luks = {
          size = "100%";
          content = {
            type = "luks";
            name = "cryptroot";
            settings.allowDiscards = true;
            # After install: systemd-cryptenroll --tpm2-device=auto --tpm2-pcrs=7 /dev/nvme0n1p2
            settings.crypttabExtraOpts = [ "tpm2-device=auto" ];
            content = {
              type = "btrfs";
              extraArgs = [ "-f" ];
              subvolumes = {
                "/root" = { mountpoint = "/";     mountOptions = [ "compress=zstd" "noatime" ]; };
                "/home" = { mountpoint = "/home"; mountOptions = [ "compress=zstd" "noatime" ]; };
                "/nix"  = { mountpoint = "/nix";  mountOptions = [ "compress=zstd" "noatime" ]; };
              };
            };
          };
        };
      };
    };
  };

  system.stateVersion = "26.05";   # set once at install, never bump
}
